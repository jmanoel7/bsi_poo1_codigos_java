package lista_agregacao;

public class TesteMoto {

	public static void main(String[] args) {
		Roda r1 = new Roda("6 palitos", "Biz 100 125");
		Roda r2 = new Roda("6 palitos", "Biz 100 125");
		Moto m1 = new Moto(r1, r2, "Honda");
		
		System.out.println(m1);
		
		m1.trocaMotor("Yamaha");
				
		System.out.println("O motor da moto foi trocado para:\n\t" + m1.getMotor());
		
		Roda rr1 = new Roda("6 palitos", "Fan 150");
		Roda rr2 = new Roda("6 palitos", "Fan 150");
		m1.trocaRodas(rr1, rr2);
						
		System.out.println("As rodas da moto foram trocadas para:\n\t" + rr1 + "\n\t" + rr2);
		
		System.out.println(m1);
	}

}
